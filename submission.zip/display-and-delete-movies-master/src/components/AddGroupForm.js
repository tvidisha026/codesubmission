import React from 'react';
import Joi from 'joi-browser';
import Form from './common/Form';
import userService from '../services/userService';
import { loginWithJwt } from '../services/authService';

class RegisterForm extends Form {
    state = {
        data: {
            firstname: '',
            lastname: '',
            color: '',
            groupnumber: ''
        },
        errors: {}
    };

    schema = {
        firstname: Joi.string()
            .min(2)
            .required()
            .label('firstname'),
        lastname: Joi.string()
            .min(2)
            .required()
            .label('lastname'),
        color: Joi.string()
            .min(2)
            .required()
            .label('color'),
        groupnumber: Joi.string()
            .min(1)
            .required()
            .label('groupnumber')
    };

    doSubmit = async () => {
        try {
            const response = await userService.register(this.state.data);
            addGroup(response.headers['x-auth-token']);
            window.location = '/';
        } catch (ex) {
            if (ex.response && ex.response.status === 400) {
                // if user has already registered & tries to register again
                // pass the DB output error message to username
                const errors = { ...this.state.errors };
                errors.username = ex.response.data;
                this.setState({ errors });
            }
        }
    };

    render() {
        return (
            <div>
                <h1>Register</h1>
                <form onSubmit={this.handleSubmit}>
                    {this.renderInput('firstname', 'firstname')} 
                    {this.renderInput('lastname', 'lastname')} 
                    {this.renderInput('color', 'color')} 
                    {this.renderInput('groupnumber', 'groupnumber')}  
                    {this.renderButton('Add Group')}
                </form>
            </div>
        );
    }
}

export default RegisterForm;
