import React, { Component } from 'react';
import { Switch, Route, Redirect } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';  
import Groups from './Groups';
import AddGroupForm from './AddGroupForm'; 
import NotFound from './NotFound'; 
import { getCurrentUser } from '../services/authService';
import 'react-toastify/dist/ReactToastify.css';

class App extends Component {
    state = {
        routes: [
            { path: '/groups', name: 'Groups' },
            { path: '/addgroup', name: 'Addgroup' } 
        ]
    };

    componentDidMount = () => {
        const user = getCurrentUser();
        this.setState({ user });
    };

    render() {
        const { routes, user } = this.state;
        return (
            <div>
                <ToastContainer />
                <Navbar routes={routes} user={user} />
                <main role="main" className="container">
                    <Switch>
                        <Route path="/groups" component={groups} />
                        <Route path="/addgroup" component={addgroup} /> 
                        <Route path="/not-found" component={NotFound} />
                        <Redirect from="/" exact to="/groups" />
                        <Redirect to="/not-found" />
                    </Switch>
                </main>
            </div>
        );
    }
}

export default App;
