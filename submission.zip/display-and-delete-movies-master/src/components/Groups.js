import React from 'react';
import { getGroups } from '../services/authService';

const Profile = () => {
    return (
        <React.Fragment>
            <h3>{getGroups().response}</h3>
            <div>This is the group view</div>
        </React.Fragment>
    );
};

export default Profile;
