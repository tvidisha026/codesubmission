import React from 'react';

const Search = ({ value, onColorSelect }) => {
    return (
        <div>
            <input
                type="text"
                value={value}
                className="form-control"
                placeholder="Search..."
                onChange={onColorSelect}
            />
            <br />
        </div>
    );
};

export default Search;
