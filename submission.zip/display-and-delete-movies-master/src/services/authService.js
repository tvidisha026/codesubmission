import http from '../services/httpService';
import jwtDecode from 'jwt-decode';

const apiEndpoint = '/auth';
const tokenKey = 'token';


const apiEndpoint1 = '/groups';
const apiEndpoint2 = '/addgroup';

http.setJwt(getJwt());

export function getGroups() {
    const jwt = localStorage.getItem(tokenKey);

    // if jwt is null stop => anonymous user
    if (!jwt) return null;

    return jwtDecode(jwt);

    return http.get(apiEndpoint1);
}

export function addGroup(group) {
    return http.post(apiEndpoint2, group);
} 
 

export function loginWithJwt(jwt) {
    localStorage.setItem(tokenKey, jwt);
}
  

export function getJwt() {
    return localStorage.getItem(tokenKey);
}

export default {
    getJwt,
    getGroups,
    addGroup,
    loginWithJwt,
    getJwt
};
