# Display and delete movies 
A react app to display and add new unstructured group with firstname, lastname, color and groupnumber

## Run the project

clone the project

select master branch

Navigate to the root folder:

```
npm install
```

``` 
npm start
``` 

browser listens to [http://localhost:3000](http://localhost:3000) as default port
